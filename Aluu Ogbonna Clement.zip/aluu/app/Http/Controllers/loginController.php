<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB;
use Auth;
use Hash;

use App\Http\Controllers\loginController;
use App\Models\administrator as admin;


class loginController extends Controller
{
     
	//Function for Administrator Login
     public function Adminlogin(Request $request){
        
        $this->validate($request,[
    		'username' => 'required',
    		'password' => 'required',

    	]); 
    	
    	$data=$request->all();
        $username=$data['username'];
        $password = $data['password'];
        $pass = md5($password);

        $myadmin = new admin;
    	$myuser = $myadmin::all()->where('username','=',$username)->first();
    	if($myuser){
    			
    		if($myuser->password == $pass){
    			session_start();
                $admindata = array('myuser'=>$myuser);
    			return view('dashboard',$admindata);
    		}else{
    			return redirect()->intended('/');
    		}

    	}else{

    		return redirect()->intended('/');
    	}
    }
    //End of Function for Administrator Login

     //Function for Administrator Logout
    public function logoutadmin(Request $request)
    {

        $this->guard()->logout();
        $request->session()->invalidate();
        return redirect()->intended('/');
    }
   // End of Function for Administrator Logout


    

   
}
